#Light On OOP

## UML ábra
<img src="LigtOnUML.drawio.png" alt="UML ábra">